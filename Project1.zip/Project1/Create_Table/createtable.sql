create table country(
country_name varchar(20),
population decimal(10,2),
no_of_worldcup_won int,
manager varchar(20),
primary key (country_name)
);

create table players(
player_id int not null,
name varchar(40) not null,
fname varchar(20) not null,
lname varchar(20) not null,
dob date,
country varchar(20) not null,
height_cms int,
club varchar(30),
position varchar(10),
caps_for_country int,
is_captain char not null,
primary key (player_id),
constraint fk_countryviolated
foreign key (country) references country(country_name)on delete cascade
);


create table match_results(
match_id int not null,
date_of_match date not null,
start_time_of_match timestamp,
team1 varchar(25),
team2 varchar(25),
team1_score int,
team2_score int,
stadium_name varchar(35),
host_city varchar(20),
primary key (match_id),
constraint fk_team1violated
foreign key(team1) references country(country_name)on delete cascade,
constraint fk_team2violated
foreign key (team2) references country(country_name)on delete cascade
);

create table player_card(
player_id int not null,
yellow_cards int,
red_cards int,
constraint fk_playedIdviolated
foreign key (player_id) references players(player_id)
on delete cascade
);

create table player_assist_goals(
player_id int not null,
no_of_matches int,
goals int,
assist int,
minutes_played int,
constraint fk_AssistGoalPlayerViolated
foreign key (player_id) references players(player_id) on delete cascade
);

