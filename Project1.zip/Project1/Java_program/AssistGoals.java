import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;


public class AssistGoals {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");

		} catch (Exception ex) {
			System.out.println("Driver not found." + ex.getMessage());
		}
		System.out.println("Driver found.");
		Connection conn=null;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/soccer", "root", "root");
		} catch (Exception ex) {
			System.out.println("Could not connect." + ex.getMessage());
		}
		String csvAssistGoal = "/Users/akshaywaikar/desktop/DBProj/Player_Assists_Goals.csv";
		String line = "";
		String sp = ",";
		try {
			PreparedStatement statement=conn.prepareStatement("Insert into player_assist_goals(player_id,no_of_matches,goals,assist,minutes_played) values(?,?,?,?,?)");
			BufferedReader br = new BufferedReader(new FileReader(csvAssistGoal));
			while ((line = br.readLine()) != null) {
				String[] disp = line.split(sp);
				System.out.println(" " + disp[0] + " " + disp[1] + " " + disp[2] + " " + disp[3]+" "+disp[4]);
				statement.setInt(1, Integer.parseInt(disp[0]));
				statement.setInt(2, Integer.parseInt(disp[1]));
				statement.setInt(3, Integer.parseInt(disp[2]));
				statement.setInt(4, Integer.parseInt(disp[3]));
				statement.setInt(5, Integer.parseInt(disp[4]));
				statement.executeUpdate();
			}
			System.out.println("Connected !");
		} catch (SQLException e) {
			System.out.println("Count not insert record."+e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
