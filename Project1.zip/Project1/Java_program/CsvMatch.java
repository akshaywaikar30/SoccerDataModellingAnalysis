

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class CsvMatch {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Found");
		} catch (Exception e) {
			System.out.println("Driver not found" + e.getMessage());
		}
		String csvMatchResults = "/Users/akshaywaikar/desktop/DBProj/Match_results.csv";
		String line = "";
		String sp = ",";
		try (BufferedReader br = new BufferedReader(new FileReader(csvMatchResults))) {
			Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/soccer", "root", "root");

			PreparedStatement statement = conn.prepareStatement(
					"Insert into match_results(match_id,date_of_match,start_time_of_match,team1,team2,team1_score,team2_score,stadium_name,host_city) values(?,?,?,?,?,?,?,?,?)");
			while ((line = br.readLine()) != null) {
				String[] disp = line.split(sp);
				System.out.println(" " + disp[0] + " " + disp[1] + " " + disp[2] + " " + disp[3] + " " + disp[4] + " "
						+ disp[5] + " " + disp[6] + " " + disp[7] + " " + disp[8]);
				statement.setInt(1, Integer.parseInt(disp[0]));
				statement.setString(2, disp[1].replaceAll("'", ""));
				statement.setString(3, disp[2].replaceAll("'", ""));
				statement.setString(4, disp[3].replaceAll("'", ""));
				statement.setString(5, disp[4].replaceAll("'", ""));
				statement.setInt(6, Integer.parseInt(disp[5]));
				statement.setInt(7, Integer.parseInt(disp[6]));
				statement.setString(8, disp[7].replaceAll("'", ""));
				statement.setString(9, disp[8].replaceAll("'", ""));
				statement.executeUpdate();
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
	}
}