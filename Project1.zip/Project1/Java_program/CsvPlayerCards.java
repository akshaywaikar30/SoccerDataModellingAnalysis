import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class CsvPlayerCards {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Found");
		} catch (Exception e) {
			System.out.println("Driver not found" + e.getMessage());
		}
		String csvPlayerCard = "/Users/akshaywaikar/desktop/DBProj/Player_Cards.csv";
		String line = "";
		String sp = ",";
		try (BufferedReader br = new BufferedReader(new FileReader(csvPlayerCard))) {
			Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/soccer", "root", "root");

			PreparedStatement statement = conn
					.prepareStatement("Insert into player_card(player_id,yellow_cards,red_cards) values(?,?,?)");
			while ((line = br.readLine()) != null) {
				String[] disp = line.split(sp);
				System.out.println(" " + disp[0] + " " + disp[1] + " " + disp[2]);
				statement.setInt(1, Integer.parseInt(disp[0]));
				statement.setInt(2, Integer.parseInt(disp[1]));
				statement.setInt(3, Integer.parseInt(disp[2]));
				statement.executeUpdate();
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

}
