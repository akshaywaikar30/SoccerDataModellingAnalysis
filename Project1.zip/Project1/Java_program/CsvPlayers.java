import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class CsvPlayers {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Found");
		}
		catch(Exception e) {
			System.out.println("Driver not found"+e.getMessage());
		}
		Connection conn=null;
		try {
			conn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/soccer", "root", "root");
		}
		catch(Exception e) {
			System.out.println("Could not make a connection"+e.getMessage());
		}
		String playersFilePath = "/Users/akshaywaikar/desktop/DBProj/Players.csv";
		String line = "";
		String sp = ",";

		try  {
			PreparedStatement statement= conn.prepareStatement("Insert into players(player_id,name,fname,lname,dob,country,height_cms,club,position,caps_for_country,is_captain) values(?,?,?,?,?,?,?,?,?,?,?)");
			BufferedReader br = new BufferedReader(new FileReader(playersFilePath));
			while ((line = br.readLine()) != null) {
				String[] res = line.split(sp);
				System.out.println(" " + res[0] + " " + res[1] + " " + res[2] + " " + res[3] + " " + res[4] + " " + res[5]
						+ " " + res[6] + " " + res[7] + " " + res[8] + " " + res[9] + " " + res[10]);
				statement.setInt(1, Integer.parseInt(res[0]));
				statement.setString(2, res[1].replaceAll("'", ""));
				statement.setString(3, res[2].replaceAll("'", ""));
				statement.setString(4, res[3].replaceAll("'", ""));
				statement.setString(5, res[4].replaceAll("'", ""));
				statement.setString(6, res[5].replaceAll("'", ""));
				statement.setInt(7, Integer.parseInt(res[6]));
				statement.setString(8, res[7].replaceAll("'", ""));
				statement.setString(9, res[8].replaceAll("'", ""));
				statement.setInt(10, Integer.parseInt(res[9]));
				statement.setString(11, Boolean.parseBoolean(res[10])==true?"Y":"N");
				statement.executeUpdate();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
